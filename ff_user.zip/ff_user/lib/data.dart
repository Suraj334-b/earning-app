import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart' show PlatformException;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:pocketbase/pocketbase.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ===========================================================================
// SERVER SETTINGS (apna server URL aur Google Web Client ID yahan daalo)
// ===========================================================================
const kApiUrl = 'https://api.yourdomain.com'; // PocketBase server (https)
const kGoogleWebClientId = 'PASTE-WEB-CLIENT-ID.apps.googleusercontent.com';

late final PocketBase pb;

/// App start par ek baar chalao (main.dart me). Login token phone me save rehta hai.
Future<void> initBackend() async {
  final prefs = await SharedPreferences.getInstance();
  final store = AsyncAuthStore(
    save: (String data) async => prefs.setString('pb_auth', data),
    initial: prefs.getString('pb_auth'),
  );
  pb = PocketBase(kApiUrl, authStore: store);
}

/// PocketBase record ko model code ke saath compatible banata hai.
class Doc {
  final String id;
  final Map<String, dynamic> _m;
  Doc(this.id, this._m);
  factory Doc.of(RecordModel r) => Doc(r.id, r.data);
  Map<String, dynamic> data() => _m;
}

// ---------------------------------------------------------------------------
// CONSTANTS
// ---------------------------------------------------------------------------
const kModes = [
  'FULL MAP', 'LW HEADSHOT', 'CS HEADSHOT',
  'LONE WOLF 1V1', 'LONE WOLF 2V2', 'LW SKILL OFF',
  'CLASH SQUAD 1V1', 'CLASH SQUAD 2V2', 'CLASH SQUAD 4V4',
  'LW LOW ENTRY', 'CS LOW ENTRY', 'LOSS TO WIN',
  'NIGHT LW 1V1', 'NIGHT LW 2V2', 'NIGHT CS 1V1',
];
const kModeArt = [
  'FULL MAP', 'LW HEAD', 'CS HEAD',
  'LW 1VS1', 'LW 2VS2', 'SKILL OFF',
  'CS 1VS1', 'CS 2VS2', 'CS 4VS4',
  'LW 1VS1', 'CS 1VS1', 'LW LOSS',
  'NIGHT MODE', 'NIGHT MODE²', 'NIGHT MODE³',
];
const kModeFees = [20, 10, 10, 15, 30, 25, 10, 20, 40, 5, 5, 10, 15, 30, 10];

const kSupportInfo = 'Support: WhatsApp / Telegram link yahan daalo';

const kDefaultRules = '''DESI CLUTCHER TM — OFFICIAL RULES

1. TEAMING & UNREGISTERED PLAYERS
• Teaming with other players is strictly prohibited.
• Inviting unregistered players is strictly prohibited.
• Violation: PERMANENT BAN — NO PENALTY OPTION.

2. NAME RULES
• Booking ke time apna Free Fire in-game name sahi daalo.
• Galat ya search na hone wala naam = NO PRIZE / NO REFUND.

3. ROOM SETTINGS
• Emulator / PC: NOT ALLOWED
• Only FREE FIRE MAX is allowed.

4. CHEATING
• Hack / script / glitch use karne par disqualify + ban.
• Cheating complaint ke liye 30 minute ke andar screen recording bhejo.

5. MISSED MATCH
• Room join na karne par: NO REFUND.

Room ID aur Password match se pehle app me join karne ke baad dikhenge.''';

int _i(dynamic v) => v is num ? v.toInt() : 0;
String _s(dynamic v) => v == null ? '' : v.toString();
DateTime _d(dynamic v) {
  if (v is String && v.isNotEmpty) {
    final x = DateTime.tryParse(v);
    if (x != null) return x.toLocal();
  }
  return DateTime.now();
}

// ---------------------------------------------------------------------------
// MODELS
// ---------------------------------------------------------------------------
class UserProfile {
  final String uid, name, email, photoUrl, ffName, ffUid, city;
  final int deposited, winning, xp, joinedCount, wins, matchesPlayed, totalWinnings;
  final bool isAdmin, banned;

  UserProfile({
    required this.uid,
    required this.name,
    required this.email,
    required this.photoUrl,
    required this.ffName,
    required this.ffUid,
    required this.city,
    required this.deposited,
    required this.winning,
    required this.xp,
    required this.joinedCount,
    required this.wins,
    required this.matchesPlayed,
    required this.totalWinnings,
    required this.isAdmin,
    required this.banned,
  });

  factory UserProfile.fromDoc(Doc d) {
    final m = d.data() ?? {};
    return UserProfile(
      uid: d.id,
      name: _s(m['name']),
      email: _s(m['email']),
      photoUrl: _s(m['photoUrl']),
      ffName: _s(m['ffName']),
      ffUid: _s(m['ffUid']),
      city: _s(m['city']),
      deposited: _i(m['deposited']),
      winning: _i(m['winning']),
      xp: _i(m['xp']),
      joinedCount: _i(m['joinedCount']),
      wins: _i(m['wins']),
      matchesPlayed: _i(m['matchesPlayed']),
      totalWinnings: _i(m['totalWinnings']),
      isAdmin: m['isAdmin'] == true,
      banned: m['banned'] == true,
    );
  }

  int get balance => deposited + winning;
  int get level => 1 + xp ~/ 1500;
  int get xpInLevel => xp % 1500;
  bool get profileDone => ffName.isNotEmpty && ffUid.isNotEmpty;
}

class Tournament {
  final String id, title, mode, teamType, version, map, rules, banner, status;
  final int entryFee, prizePool, perKill, maxSlots, joined;
  final DateTime startTime;
  final bool joiningOpen;

  Tournament({
    required this.id,
    required this.title,
    required this.mode,
    required this.teamType,
    required this.version,
    required this.map,
    required this.rules,
    required this.banner,
    required this.status,
    required this.entryFee,
    required this.prizePool,
    required this.perKill,
    required this.maxSlots,
    required this.joined,
    required this.startTime,
    required this.joiningOpen,
  });

  factory Tournament.fromDoc(Doc d) {
    final m = d.data() ?? {};
    return Tournament(
      id: d.id,
      title: _s(m['title']),
      mode: _s(m['mode']),
      teamType: _s(m['teamType']).isEmpty ? 'Solo' : _s(m['teamType']),
      version: _s(m['version']).isEmpty ? 'TPP' : _s(m['version']),
      map: _s(m['map']).isEmpty ? 'BERMUDA' : _s(m['map']),
      rules: _s(m['rules']).isEmpty ? kDefaultRules : _s(m['rules']),
      banner: _s(m['banner']),
      status: _s(m['status']).isEmpty ? 'upcoming' : _s(m['status']),
      entryFee: _i(m['entryFee']),
      prizePool: _i(m['prizePool']),
      perKill: _i(m['perKill']),
      maxSlots: _i(m['maxSlots']) == 0 ? 48 : _i(m['maxSlots']),
      joined: _i(m['joined']),
      startTime: _d(m['startTime']),
      joiningOpen: m['joiningOpen'] != false,
    );
  }

  int get slotsLeft => maxSlots - joined;
}

class Entry {
  final int position;
  final String uid, ffName;
  Entry({required this.position, required this.uid, required this.ffName});
}

class TxnRecord {
  final String type, note;
  final int amount;
  final DateTime createdAt;
  TxnRecord(this.type, this.amount, this.note, this.createdAt);
  bool get isCredit => type == 'credit';
}

/// Coin pack (FIXED). `paise` = Razorpay amount (10.10 rupees = 1010 paise).
class CoinPack {
  final int coins, paise;
  const CoinPack(this.coins, this.paise);
  String get id => 'p$coins';
  String get label => paise % 100 == 0
      ? '₹${paise ~/ 100}'
      : '₹${(paise / 100).toStringAsFixed(2)}';
}

class AppConfig {
  final String announcement, supportInfo, homeBannerUrl;
  final int minWithdraw;
  const AppConfig({
    this.announcement = '',
    this.supportInfo = kSupportInfo,
    this.homeBannerUrl = '',
    this.minWithdraw = 50,
  });
}

class PaymentRec {
  final String id, uid, status;
  final int paise, coins;
  final DateTime createdAt;
  PaymentRec(this.id, this.uid, this.status, this.paise, this.coins, this.createdAt);
  String get priceLabel => CoinPack(coins, paise).label;
}

class WithdrawRecord {
  final String id, upi, status;
  final int amount;
  final DateTime createdAt;
  WithdrawRecord(this.id, this.amount, this.upi, this.status, this.createdAt);
}

// ---------------------------------------------------------------------------
// ERRORS (friendly Hinglish messages)
// ---------------------------------------------------------------------------
String friendlyError(Object e) {
  if (e is ClientException) {
    if (e.statusCode == 0) {
      return 'Server se connect nahi ho pa raha. Internet check karo';
    }
    final r = e.response;
    final data = r['data'];
    if (data is Map && data.isNotEmpty) {
      final first = data.values.first;
      if (first is Map) {
        if (first['code'] == 'validation_not_unique') {
          return 'Ye email pehle se registered hai';
        }
        if (first['message'] != null) return first['message'].toString();
      }
    }
    final msg = r['message']?.toString() ?? '';
    if (msg.toLowerCase().contains('failed to authenticate')) {
      return 'Email ya password galat hai';
    }
    if (e.statusCode == 401) return 'Pehle login karo';
    return msg.isEmpty ? 'Server error (${e.statusCode})' : msg;
  }
  if (e is GoogleSignInException) {
    return e.code == GoogleSignInExceptionCode.canceled
        ? 'Login cancel ho gaya'
        : 'Google login fail hua (SHA-1 / Client ID check karo): $e';
  }
  if (e is PlatformException) return e.message ?? e.code;
  if (e is String) return e;
  return e.toString();
}

// ---------------------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------------------
class AuthUser {
  final String id, email, photoUrl;
  const AuthUser(this.id, this.email, this.photoUrl);
}

class AuthService {
  static AuthUser? get user {
    if (!pb.authStore.isValid) return null;
    final r = pb.authStore.record;
    if (r == null) return null;
    return AuthUser(r.id, r.get<String>('email', ''), r.get<String>('photoUrl', ''));
  }

  static Stream<AuthUser?> get authChanges async* {
    yield user;
    await for (final _ in pb.authStore.onChange) {
      yield user;
    }
  }

  static Future<void>? _googleInit;

  static Future<void> signInWithGoogle() async {
    if (kIsWeb) throw 'Web par Google login abhi support nahi hai';
    _googleInit ??= GoogleSignIn.instance.initialize(serverClientId: kGoogleWebClientId);
    await _googleInit;
    final account = await GoogleSignIn.instance.authenticate();
    final idToken = account.authentication.idToken;
    if (idToken == null) throw 'Google token nahi mila';
    final res = await pb.send('/api/dc/google',
        method: 'POST', body: {'idToken': idToken}) as Map;
    final rec = Map<String, dynamic>.from(res['record'] as Map);
    if ((rec['email'] ?? '').toString().isEmpty) rec['email'] = res['email'];
    pb.authStore.save(res['token'] as String, RecordModel.fromJson(rec));
  }

  static Future<void> emailLogin(String email, String pass) async {
    await pb.collection('players').authWithPassword(email.trim(), pass);
  }

  static Future<void> emailRegister(String name, String email, String pass) async {
    await pb.collection('players').create(body: {
      'email': email.trim(),
      'emailVisibility': true,
      'password': pass,
      'passwordConfirm': pass,
      'name': name,
    });
    await emailLogin(email, pass);
  }

  static Future<void> resetPassword(String email) =>
      pb.collection('players').requestPasswordReset(email.trim());

  static Future<void> signOut() async {
    try {
      await GoogleSignIn.instance.signOut();
    } catch (_) {}
    pb.authStore.clear();
  }
}

// ---------------------------------------------------------------------------
// REPOSITORY (PocketBase)
// ---------------------------------------------------------------------------
/// Realtime: collection badle to data dobara laata hai. UI ko Stream milta hai.
Stream<T> _watch<T>(List<String> collections, Future<T> Function() fetch) {
  late StreamController<T> c;
  final unsubs = <Future<UnsubscribeFunc>>[];
  Timer? debounce, poll;

  Future<void> load() async {
    try {
      final v = await fetch();
      if (!c.isClosed) c.add(v);
    } catch (e, s) {
      if (!c.isClosed) c.addError(e, s);
    }
  }

  void trigger() {
    debounce?.cancel();
    debounce = Timer(const Duration(milliseconds: 250), load);
  }

  c = StreamController<T>(
    onListen: () {
      load();
      for (final col in collections) {
        unsubs.add(pb.collection(col).subscribe('*', (_) => trigger()));
      }
      poll = Timer.periodic(const Duration(seconds: 30), (_) => load());
    },
    onCancel: () async {
      debounce?.cancel();
      poll?.cancel();
      for (final u in unsubs) {
        try {
          (await u)();
        } catch (_) {}
      }
      unsubs.clear();
    },
  );
  return c.stream;
}

bool _notFound(Object e) => e is ClientException && e.statusCode == 404;

class Repo {
  static String get uid => pb.authStore.record!.id;

  static String _f(String expr, Map<String, dynamic> p) => pb.filter(expr, p);

  // ---- streams ----
  static Stream<UserProfile?> userStream(String u) =>
      _watch<UserProfile?>(['players'], () async {
        try {
          return UserProfile.fromDoc(Doc.of(await pb.collection('players').getOne(u)));
        } catch (e) {
          if (_notFound(e)) return null;
          rethrow;
        }
      });

  static Stream<List<Tournament>> tournaments() =>
      _watch<List<Tournament>>(['tournaments'], () async {
        final l = await pb.collection('tournaments').getFullList(sort: 'startTime');
        return l.map((r) => Tournament.fromDoc(Doc.of(r))).toList();
      });

  static Stream<Tournament?> tournament(String id) =>
      _watch<Tournament?>(['tournaments'], () async {
        try {
          return Tournament.fromDoc(Doc.of(await pb.collection('tournaments').getOne(id)));
        } catch (e) {
          if (_notFound(e)) return null;
          rethrow;
        }
      });

  static Stream<List<Entry>> entries(String tid) =>
      _watch<List<Entry>>(['entries'], () async {
        final l = await pb.collection('entries').getFullList(
            filter: _f('tid = {:t}', {'t': tid}), sort: 'position');
        return l
            .map((r) => Entry(
                position: _i(r.data['position']),
                uid: _s(r.data['uid']),
                ffName: _s(r.data['ffName'])))
            .toList();
      });

  static Stream<Set<String>> joinedIds(String u) =>
      _watch<Set<String>>(['entries'], () async {
        final l = await pb.collection('entries').getFullList(
            filter: _f('uid = {:u}', {'u': u}));
        return l.map((r) => _s(r.data['tid'])).toSet();
      });

  static Stream<bool> isJoined(String u, String tid) =>
      _watch<bool>(['entries'], () async {
        final r = await pb.collection('entries').getList(
            page: 1,
            perPage: 1,
            filter: _f('uid = {:u} && tid = {:t}', {'u': u, 't': tid}));
        return r.items.isNotEmpty;
      });

  static Stream<List<TxnRecord>> transactions(String u) =>
      _watch<List<TxnRecord>>(['transactions'], () async {
        final r = await pb.collection('transactions').getList(
            page: 1,
            perPage: 100,
            sort: '-created',
            filter: _f('uid = {:u}', {'u': u}));
        return r.items.map((x) {
          final m = x.data;
          return TxnRecord(_s(m['type']), _i(m['amount']), _s(m['note']), _d(m['created']));
        }).toList();
      });

  /// Room ID/Password: server rules ke hisaab se sirf joined players ko milta hai.
  static Stream<Map<String, dynamic>> room(String tid) =>
      _watch<Map<String, dynamic>>(['rooms'], () async {
        try {
          final r = await pb.collection('rooms').getFirstListItem(_f('tid = {:t}', {'t': tid}));
          return Map<String, dynamic>.from(r.data);
        } catch (e) {
          if (_notFound(e)) return <String, dynamic>{};
          rethrow;
        }
      });

  // ---- coin packs (FIXED; server hooks/lib.js ke PACKS se same) ----
  static const fixedPacks = [
    CoinPack(10, 1010), //  10 coins  -> ₹10.10
    CoinPack(20, 2015), //  20 coins  -> ₹20.15
    CoinPack(50, 5050), //  50 coins  -> ₹50.50
    CoinPack(100, 10100), // 100 coins -> ₹101
    CoinPack(200, 20200), // 200 coins -> ₹202
    CoinPack(500, 50500), // 500 coins -> ₹505
  ];

  static Stream<List<CoinPack>> packs() => Stream.value(fixedPacks);

  // ---- app config ----
  static Stream<AppConfig> config() => _watch<AppConfig>(['config'], () async {
        try {
          final m = (await pb.collection('config').getOne('appconfig000000')).data;
          return AppConfig(
            announcement: _s(m['announcement']),
            supportInfo: _s(m['supportInfo']).isEmpty ? kSupportInfo : _s(m['supportInfo']),
            homeBannerUrl: _s(m['homeBannerUrl']),
            minWithdraw: m['minWithdraw'] == null ? 50 : _i(m['minWithdraw']),
          );
        } catch (e) {
          if (_notFound(e)) return const AppConfig();
          rethrow;
        }
      });

  // ---- user history ----
  static Stream<List<PaymentRec>> myOrders(String u) =>
      _watch<List<PaymentRec>>(['orders'], () async {
        final l = await pb.collection('orders').getFullList(
            filter: _f('uid = {:u}', {'u': u}), sort: '-created');
        return l.map((r) {
          final m = r.data;
          return PaymentRec(_s(m['orderId']), _s(m['uid']), _s(m['status']),
              _i(m['paise']), _i(m['coins']), _d(m['created']));
        }).toList();
      });

  static Stream<List<WithdrawRecord>> withdrawals(String u) =>
      _watch<List<WithdrawRecord>>(['withdraws'], () async {
        final l = await pb.collection('withdraws').getFullList(
            filter: _f('uid = {:u}', {'u': u}), sort: '-created');
        return l.map((r) {
          final m = r.data;
          return WithdrawRecord(r.id, _i(m['amount']), _s(m['upi']),
              _s(m['status']), _d(m['created']));
        }).toList();
      });

  // ---- actions ----
  static Future<void> saveProfile(
      {required String ffName, required String ffUid, required String city}) async {
    await pb.collection('players').update(uid, body: {
      'ffName': ffName,
      'ffUid': ffUid,
      'city': city,
    });
  }

  /// Join (server par atomic: balance, slot, position sab check hota hai)
  static Future<void> joinTournament({
    required Tournament t,
    required int position,
    required String ffName,
  }) async {
    await pb.send('/api/dc/join',
        method: 'POST',
        body: {'tid': t.id, 'position': position, 'ffName': ffName});
  }

  static Future<void> requestWithdraw(int amount, String upi, String name) async {
    await pb.send('/api/dc/withdraw',
        method: 'POST', body: {'amount': amount, 'upi': upi});
  }
}
