import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'data.dart';
import 'tournaments.dart';
import 'wallet_profile.dart';

// ---------------------------------------------------------------------------
// SHELL: top bar + bottom nav (Home, Tournaments, Wallet, Profile)
// ---------------------------------------------------------------------------
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _index = 0;
  static const _titles = ['DESI CLUTCHER TM', 'TOURNAMENTS', 'WALLET', 'PROFILE'];

  void _go(int i) => setState(() => _index = i);

  Widget _nav(int i, IconData icon, String label) {
    final sel = _index == i;
    final color = sel ? kYellow : Colors.white38;
    return Expanded(
      child: InkWell(
        onTap: () => _go(i),
        child: Column(
          children: [
            Container(
                height: 3,
                width: 44,
                color: sel ? kYellow : Colors.transparent),
            const Spacer(),
            Icon(icon, color: color, size: 28),
            Text(label,
                style: TextStyle(
                    color: color, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => _go(3),
              child: Avatar(url: AuthService.user?.photoUrl ?? ''),
            ),
            Expanded(
              child: Text(_titles[_index],
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: kYellow,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1)),
            ),
            GestureDetector(
              onTap: () => snack(context, 'Koi nayi notification nahi hai'),
              child: const Stack(
                children: [
                  Icon(Icons.notifications_none, color: kYellow, size: 34),
                  Positioned(
                    right: 4,
                    top: 2,
                    child:
                        CircleAvatar(radius: 4.5, backgroundColor: Colors.red),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _topBar(),
            Expanded(
              child: IndexedStack(
                index: _index,
                children: [
                  HomeTab(onTab: _go),
                  const TournamentsTab(),
                  const WalletTab(),
                  const ProfileTab(),
                ],
              ),
            ),
            Container(
              height: 66,
              decoration: const BoxDecoration(
                color: kDeep,
                border: Border(top: BorderSide(color: Colors.white10)),
              ),
              child: Row(
                children: [
                  _nav(0, Icons.home, 'Home'),
                  _nav(1, Icons.emoji_events, 'Tournaments'),
                  _nav(2, Icons.account_balance_wallet, 'Wallet'),
                  _nav(3, Icons.person, 'Profile'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// HOME TAB: banner, quick buttons, TOURNAMENT -> sab game modes
// ---------------------------------------------------------------------------
class HomeTab extends StatelessWidget {
  final void Function(int tab) onTab;
  const HomeTab({super.key, required this.onTab});

  Widget _assetBanner() => Image.asset(
        'assets/home_banner.jpg',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          height: 180,
          alignment: Alignment.center,
          decoration: const BoxDecoration(gradient: kGrad),
          child: const Text('FREE FIRE TOURNAMENTS\nWIN REAL PRIZES',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        ),
      );

  Widget _quick(IconData icon, String label, VoidCallback onTap) => Expanded(
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            height: 92,
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kOrange, width: 1.2),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 38, color: kYellow),
                const SizedBox(height: 6),
                Text(label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
      children: [
        Live<AppConfig>(
          create: Repo.config,
          loading: const SizedBox(height: 180),
          builder: (context, cfg) => Column(
            children: [
              if (cfg.announcement.isNotEmpty)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kYellow),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.campaign, color: kYellow),
                      const SizedBox(width: 10),
                      Expanded(child: Text(cfg.announcement)),
                    ],
                  ),
                ),
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: cfg.homeBannerUrl.isNotEmpty
                    ? Image.network(cfg.homeBannerUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _assetBanner())
                    : _assetBanner(),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _quick(Icons.emoji_events, 'Tournaments', () => onTab(1)),
            const SizedBox(width: 8),
            _quick(
                Icons.sports_martial_arts,
                'My Matches',
                () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const MyMatchesScreen()))),
            const SizedBox(width: 8),
            _quick(Icons.account_balance_wallet, 'Wallet', () => onTab(2)),
            const SizedBox(width: 8),
            _quick(
                Icons.person_add,
                'Refer & Earn',
                () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ReferScreen()))),
          ],
        ),
        const SizedBox(height: 18),
        const Row(
          children: [
            Text('TOURNAMENT',
                style: TextStyle(
                    color: kYellow, fontSize: 22, fontWeight: FontWeight.w900)),
            SizedBox(width: 12),
            Expanded(child: Divider(color: Colors.white24)),
          ],
        ),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 0.92,
          ),
          itemCount: kModes.length,
          itemBuilder: (context, i) => _ModeTile(i),
        ),
      ],
    );
  }
}

class _ModeTile extends StatelessWidget {
  final int i;
  const _ModeTile(this.i);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ModeTournamentsScreen(mode: kModes[i]))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: const BoxDecoration(gradient: kGrad),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Icon(modeIcon(kModes[i]),
                          size: 54, color: Colors.white24),
                    ),
                    Positioned(
                      left: 4,
                      right: 4,
                      bottom: 6,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(kModeArt[i],
                            style: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                fontStyle: FontStyle.italic,
                                shadows: [
                                  Shadow(color: Colors.black, blurRadius: 6)
                                ])),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 7),
              color: kOrange,
              child: Text(kModes[i],
                  textAlign: TextAlign.center,
                  style:
                      const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// TOURNAMENTS TAB: sab tournaments + mode filter
// ---------------------------------------------------------------------------
class TournamentsTab extends StatefulWidget {
  const TournamentsTab({super.key});

  @override
  State<TournamentsTab> createState() => _TournamentsTabState();
}

class _TournamentsTabState extends State<TournamentsTab> {
  String _mode = 'ALL';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 54,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: ['ALL', ...kModes]
                .map((m) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(m),
                        selected: _mode == m,
                        selectedColor: kOrange,
                        onSelected: (_) => setState(() => _mode = m),
                      ),
                    ))
                .toList(),
          ),
        ),
        Expanded(
          child: TournamentListView(
            filter: (t, j) =>
                (_mode == 'ALL' || t.mode == _mode) &&
                t.status != 'completed' &&
                t.status != 'cancelled',
            emptyText: 'Koi tournament nahi mila',
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// REFER & EARN (referral code dikhata hai; bonus logic baad me backend se)
// ---------------------------------------------------------------------------
class ReferScreen extends StatelessWidget {
  const ReferScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final code = Repo.uid.substring(0, 8).toUpperCase();
    return Scaffold(
      appBar: AppBar(title: const Text('Refer & Earn')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
                gradient: kGrad, borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                const Icon(Icons.card_giftcard, size: 56),
                const SizedBox(height: 8),
                const Text('REFER & EARN',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        fontStyle: FontStyle.italic)),
                const Text('Dosto ko invite karo',
                    style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                      color: Colors.black38,
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(code,
                          style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2)),
                      IconButton(
                        icon: const Icon(Icons.copy, size: 18),
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: code));
                          snack(context, 'Referral code copy ho gaya');
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
