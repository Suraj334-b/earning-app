import 'package:flutter/material.dart';
import 'core.dart';
import 'data.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false, _emailMode = false, _register = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      if (mounted) snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _submitEmail() {
    if (!_form.currentState!.validate()) return;
    _run(() => _register
        ? AuthService.emailRegister(
            _name.text.trim(), _email.text.trim(), _pass.text)
        : AuthService.emailLogin(_email.text.trim(), _pass.text));
  }

  Future<void> _forgot() async {
    final mail = _email.text.trim();
    if (!mail.contains('@')) {
      snack(context, 'Pehle upar apna email daalo');
      return;
    }
    await _run(() async {
      await AuthService.resetPassword(mail);
      if (mounted) snack(context, 'Password reset link email par bhej diya');
    });
  }

  InputDecoration _dec(String label, IconData icon) => InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: kYellow),
        filled: true,
        fillColor: kDeep,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.white24)),
      );

  Widget _googleButton() => GestureDetector(
        onTap: _busy ? null : () => _run(AuthService.signInWithGoogle),
        child: Container(
          height: 58,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kYellow, width: 1.5),
            boxShadow: [BoxShadow(color: kYellow.withAlpha(90), blurRadius: 18)],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('G',
                  style: TextStyle(
                      color: Color(0xFF4285F4),
                      fontSize: 26,
                      fontWeight: FontWeight.w900)),
              SizedBox(width: 12),
              Text('Continue with Google',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 17,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );

  Widget _emailForm() => Form(
        key: _form,
        child: Column(
          children: [
            if (_register) ...[
              TextFormField(
                controller: _name,
                decoration: _dec('Naam', Icons.person),
                validator: (v) =>
                    (v == null || v.trim().length < 2) ? 'Naam daalo' : null,
              ),
              const SizedBox(height: 12),
            ],
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              decoration: _dec('Email', Icons.email),
              validator: (v) =>
                  (v == null || !v.contains('@')) ? 'Sahi email daalo' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _pass,
              obscureText: true,
              decoration: _dec('Password', Icons.lock),
              validator: (v) => (v == null || v.length < 6)
                  ? 'Kam se kam 6 akshar'
                  : null,
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: kYellow, foregroundColor: Colors.black),
                onPressed: _busy ? null : _submitEmail,
                child: Text(_register ? 'REGISTER' : 'LOGIN',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => setState(() => _register = !_register),
                  child: Text(_register
                      ? 'Account hai? Login'
                      : 'Naya account banao'),
                ),
                if (!_register)
                  TextButton(
                      onPressed: _busy ? null : _forgot,
                      child: const Text('Forgot password?')),
              ],
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Image.asset(
                  'assets/login_header.jpg',
                  width: double.infinity,
                  fit: BoxFit.fitWidth,
                  errorBuilder: (_, __, ___) => const SizedBox(height: 260),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: 90,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, kBg],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (_busy)
              const LinearProgressIndicator(color: kYellow, minHeight: 2),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: Column(
                children: [
                  Container(width: 70, height: 3, color: kYellow),
                  const SizedBox(height: 14),
                  const Text.rich(TextSpan(children: [
                    TextSpan(text: 'Welcome '),
                    TextSpan(text: 'Back', style: TextStyle(color: kYellow)),
                  ]), style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  const Text('Sign in to continue to Free Fire Tournament',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 22),
                  _googleButton(),
                  const SizedBox(height: 18),
                  const Row(
                    children: [
                      Expanded(child: Divider(color: Colors.white24)),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 14),
                        child: Text('OR', style: TextStyle(color: Colors.white60)),
                      ),
                      Expanded(child: Divider(color: Colors.white24)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  if (!_emailMode)
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white38),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16))),
                        onPressed: () => setState(() => _emailMode = true),
                        icon: const Icon(Icons.email_outlined),
                        label: const Text('Continue with Email'),
                      ),
                    )
                  else
                    _emailForm(),
                  const SizedBox(height: 28),
                  const Icon(Icons.shield, color: kYellow, size: 30),
                  const SizedBox(height: 4),
                  const Text('Secure Login',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  const Text('Your data is safe with us',
                      style: TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
