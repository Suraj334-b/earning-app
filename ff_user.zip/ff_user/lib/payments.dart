import 'dart:async';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'data.dart';

/// Coins kharidne ka poora flow:
/// 1. Apna server `/api/dc/order` -> Razorpay order (amount server decide karta hai)
/// 2. Razorpay checkout app me khulta hai
/// 3. Apna server `/api/dc/verify` signature check karke coins wallet me daalta hai
class PaymentService {
  static Future<void> buyPack(CoinPack pack, {String email = ''}) async {
    final res = await pb.send('/api/dc/order',
        method: 'POST', body: {'packId': pack.id}) as Map;
    final data = Map<String, dynamic>.from(res);

    final done = Completer<PaymentSuccessResponse>();
    final rz = Razorpay();
    rz.on(Razorpay.EVENT_PAYMENT_SUCCESS, (PaymentSuccessResponse r) {
      if (!done.isCompleted) done.complete(r);
    });
    rz.on(Razorpay.EVENT_PAYMENT_ERROR, (PaymentFailureResponse r) {
      if (!done.isCompleted) {
        done.completeError(r.message ?? 'Payment cancel / fail ho gaya');
      }
    });
    rz.on(Razorpay.EVENT_EXTERNAL_WALLET, (ExternalWalletResponse r) {});

    try {
      rz.open({
        'key': data['keyId'],
        'amount': data['amount'],
        'order_id': data['orderId'],
        'name': 'Desi Clutcher TM',
        'description': '${pack.coins} Coins',
        'prefill': {'email': email},
        'theme': {'color': '#FFC107'},
      });
      final ok = await done.future;
      await pb.send('/api/dc/verify', method: 'POST', body: {
        'orderId': ok.orderId,
        'paymentId': ok.paymentId,
        'signature': ok.signature,
      });
    } finally {
      rz.clear();
    }
  }
}
