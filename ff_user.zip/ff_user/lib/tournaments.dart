import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'data.dart';

const _statusLabels = {
  'upcoming': 'UPCOMING',
  'ongoing': 'LIVE',
  'completed': 'RESULT',
  'cancelled': 'CANCELLED',
};

// ---------------------------------------------------------------------------
// LIST VIEW (filter ke hisaab se tournaments)
// ---------------------------------------------------------------------------
class TournamentListView extends StatelessWidget {
  final bool Function(Tournament t, Set<String> joined) filter;
  final String emptyText;
  const TournamentListView(
      {super.key, required this.filter, required this.emptyText});

  @override
  Widget build(BuildContext context) {
    return Live<List<Tournament>>(
      create: Repo.tournaments,
      builder: (context, all) => Live<Set<String>>(
        create: () => Repo.joinedIds(Repo.uid),
        builder: (context, joined) {
          final list = all.where((t) => filter(t, joined)).toList();
          if (list.isEmpty) {
            return Center(
                child: Text(emptyText,
                    style: const TextStyle(color: Colors.white60)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            itemBuilder: (_, i) =>
                TournamentCard(t: list[i], joined: joined.contains(list[i].id)),
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// CARD
// ---------------------------------------------------------------------------
class TournamentCard extends StatelessWidget {
  final Tournament t;
  final bool joined;
  const TournamentCard({super.key, required this.t, required this.joined});

  void _open(BuildContext context) => Navigator.push(context,
      MaterialPageRoute(builder: (_) => TournamentDetailScreen(t0: t)));

  Widget _stat(String label, String value) => Expanded(
        child: Column(
          children: [
            Text(label,
                style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 11,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(value,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white)),
          ],
        ),
      );

  Widget _meta(IconData icon, String label, String value) => Column(
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: kOrange),
              const SizedBox(width: 4),
              Text(label,
                  style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 4),
          Text(value,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ],
      );

  String get _btnLabel {
    if (joined) return 'JOINED';
    if (t.status == 'ongoing') return 'LIVE';
    if (t.status == 'completed') return 'RESULT';
    if (t.status == 'cancelled') return 'CANCELLED';
    if (!t.joiningOpen) return 'CLOSED';
    if (t.slotsLeft <= 0) return 'FULL';
    return 'JOIN';
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _open(context),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kOrange.withAlpha(110)),
        ),
        child: Column(
          children: [
            ModeBanner(mode: t.mode, banner: t.banner, height: 160),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                            gradient: kGrad,
                            borderRadius: BorderRadius.circular(12)),
                        child: Icon(modeIcon(t.mode), color: kYellow),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(t.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 2),
                            Text(fmtDate(t.startTime),
                                style: const TextStyle(color: Colors.white54)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                        color: kDeep, borderRadius: BorderRadius.circular(14)),
                    child: Row(
                      children: [
                        _stat('PRIZE POOL', '🪙${t.prizePool}'),
                        Container(width: 1, height: 36, color: Colors.white12),
                        _stat('PER KILL', '🪙${t.perKill}'),
                        Container(width: 1, height: 36, color: Colors.white12),
                        _stat('ENTRY FEE',
                            t.entryFee == 0 ? 'FREE' : '🪙${t.entryFee}'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _meta(Icons.person, 'TYPE', t.teamType),
                      _meta(Icons.layers, 'VERSION', t.version),
                      _meta(Icons.place, 'MAP', t.map),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: (t.joined / t.maxSlots).clamp(0.0, 1.0),
                                minHeight: 6,
                                color: kOrange,
                                backgroundColor: Colors.white12,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text('${t.joined}/${t.maxSlots}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      SizedBox(
                        width: 130,
                        height: 48,
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                              backgroundColor:
                                  joined ? Colors.green : kOrange,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12))),
                          onPressed: () => _open(context),
                          child: Text(_btnLabel,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 16)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// MODE SCREEN: ONGOING / UPCOMING / RESULTS
// ---------------------------------------------------------------------------
class ModeTournamentsScreen extends StatelessWidget {
  final String mode;
  const ModeTournamentsScreen({super.key, required this.mode});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      initialIndex: 1,
      child: Scaffold(
        appBar: AppBar(
          title: Text(mode),
          actions: [
            MeBuilder(
              loading: const SizedBox.shrink(),
              builder: (_, me) => Container(
                margin: const EdgeInsets.only(right: 12),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                    color: kDeep,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kYellow)),
                child: Text('🪙${me.balance}',
                    style: const TextStyle(
                        color: kYellow,
                        fontWeight: FontWeight.w900,
                        fontSize: 16)),
              ),
            ),
          ],
          bottom: const TabBar(
            indicatorColor: kYellow,
            labelColor: kYellow,
            tabs: [
              Tab(text: 'ONGOING'),
              Tab(text: 'UPCOMING'),
              Tab(text: 'RESULTS'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            for (final s in ['ongoing', 'upcoming', 'completed'])
              TournamentListView(
                filter: (t, j) => t.mode == mode && t.status == s,
                emptyText: 'Abhi koi ${_statusLabels[s]!.toLowerCase()} match nahi',
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// MY MATCHES
// ---------------------------------------------------------------------------
class MyMatchesScreen extends StatelessWidget {
  const MyMatchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My Matches'),
          bottom: const TabBar(
            indicatorColor: kYellow,
            labelColor: kYellow,
            tabs: [
              Tab(text: 'Upcoming'),
              Tab(text: 'Ongoing'),
              Tab(text: 'Completed'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            for (final s in ['upcoming', 'ongoing', 'completed'])
              TournamentListView(
                filter: (t, j) => j.contains(t.id) && t.status == s,
                emptyText: 'Koi $s match nahi hai',
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// DETAILS
// ---------------------------------------------------------------------------
class TournamentDetailScreen extends StatefulWidget {
  final Tournament t0;
  const TournamentDetailScreen({super.key, required this.t0});

  @override
  State<TournamentDetailScreen> createState() => _TournamentDetailScreenState();
}

class _TournamentDetailScreenState extends State<TournamentDetailScreen> {
  late final Stream<Tournament?> _ts = Repo.tournament(widget.t0.id);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Tournament?>(
      initialData: widget.t0,
      stream: _ts,
      builder: (context, snap) {
        final t = snap.data ?? widget.t0;
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              title: Text(t.title, style: const TextStyle(fontSize: 16)),
            ),
            body: Column(
              children: [
                ModeBanner(mode: t.mode, banner: t.banner, height: 180),
                const TabBar(
                  indicatorColor: kOrange,
                  labelColor: kOrange,
                  tabs: [Tab(text: 'DESCRIPTION'), Tab(text: 'JOINED MEMBER')],
                ),
                Expanded(
                  child: TabBarView(
                    children: [_Description(t: t), _Members(t: t)],
                  ),
                ),
              ],
            ),
            bottomNavigationBar: _JoinBar(t: t),
          ),
        );
      },
    );
  }
}

class _JoinBar extends StatelessWidget {
  final Tournament t;
  const _JoinBar({required this.t});

  @override
  Widget build(BuildContext context) {
    return Live<bool>(
      create: () => Repo.isJoined(Repo.uid, t.id),
      loading: const SizedBox(height: 76),
      builder: (context, joined) {
        String label = 'JOIN NOW';
        bool enabled = true;
        if (joined) {
          label = 'JOINED ✓';
          enabled = false;
        } else if (t.status != 'upcoming') {
          label = _statusLabels[t.status] ?? t.status.toUpperCase();
          enabled = false;
        } else if (!t.joiningOpen) {
          label = 'JOINING BAND';
          enabled = false;
        } else if (t.slotsLeft <= 0) {
          label = 'SLOTS FULL';
          enabled = false;
        }
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              height: 52,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: kOrange,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12))),
                onPressed: enabled
                    ? () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PositionPickerScreen(t: t)))
                    : null,
                child: Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 17)),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _Description extends StatelessWidget {
  final Tournament t;
  const _Description({required this.t});

  Widget _chip(String k, String v) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white12),
        ),
        child: Text.rich(TextSpan(children: [
          TextSpan(text: '$k : ', style: const TextStyle(color: Colors.white60)),
          TextSpan(text: v, style: const TextStyle(fontWeight: FontWeight.w800)),
        ])),
      );

  Widget _heading(String s) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(s,
            style: const TextStyle(
                color: kOrange, fontSize: 18, fontWeight: FontWeight.w800)),
      );

  Widget _roomCard(BuildContext context) {
    return Live<bool>(
      create: () => Repo.isJoined(Repo.uid, t.id),
      builder: (context, joined) {
        if (!joined) {
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12)),
            child: const Text(
                '🔒 Room ID aur Password join karne ke baad yahan dikhenge.'),
          );
        }
        return Live<Map<String, dynamic>>(
          create: () => Repo.room(t.id),
          builder: (context, room) {
            final id = room['roomId']?.toString() ?? '';
            final pw = room['roomPass']?.toString() ?? '';
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: Colors.green.withAlpha(30),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green)),
              child: id.isEmpty
                  ? const Text('Room ID abhi set nahi hui. Match se pehle yahan aa jayegi.')
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Room Details',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        _copy(context, 'Room ID', id),
                        _copy(context, 'Password', pw),
                      ],
                    ),
            );
          },
        );
      },
    );
  }

  Widget _copy(BuildContext context, String k, String v) => Row(
        children: [
          Text('$k: ', style: const TextStyle(color: Colors.white60)),
          Text(v, style: const TextStyle(fontWeight: FontWeight.bold)),
          IconButton(
            icon: const Icon(Icons.copy, size: 18),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: v));
              snack(context, '$k copy ho gaya');
            },
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(t.title,
            style: const TextStyle(
                color: kOrange, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _chip('Team', t.teamType),
          _chip('Entry Fee', t.entryFee == 0 ? 'FREE' : '🪙${t.entryFee}'),
          _chip('Match Type', t.entryFee == 0 ? 'FREE' : 'PAID'),
          _chip('Map', t.map),
          _chip('Match Schedule', fmtDate(t.startTime)),
        ]),
        _heading('Price Details'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _chip('Winning Prize', '🪙${t.prizePool}'),
          _chip('Per Kill', '🪙${t.perKill}'),
        ]),
        _heading('Room Details'),
        _roomCard(context),
        _heading('About this Match'),
        Text(t.rules, style: const TextStyle(height: 1.5)),
        const SizedBox(height: 16),
      ],
    );
  }
}

class _Members extends StatelessWidget {
  final Tournament t;
  const _Members({required this.t});

  @override
  Widget build(BuildContext context) {
    return Live<List<Entry>>(
      create: () => Repo.entries(t.id),
      builder: (context, list) {
        if (list.isEmpty) {
          return const Center(
              child: Text('Abhi tak koi join nahi hua',
                  style: TextStyle(color: Colors.white60)));
        }
        return ListView.builder(
          itemCount: list.length,
          itemBuilder: (_, i) {
            final e = list[i];
            return ListTile(
              leading: CircleAvatar(
                  backgroundColor: kOrange, child: Text('${e.position}')),
              title: Text(e.ffName),
            );
          },
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// STEP 1: SELECT MATCH POSITION
// ---------------------------------------------------------------------------
class PositionPickerScreen extends StatefulWidget {
  final Tournament t;
  const PositionPickerScreen({super.key, required this.t});

  @override
  State<PositionPickerScreen> createState() => _PositionPickerScreenState();
}

class _PositionPickerScreenState extends State<PositionPickerScreen> {
  int? _sel;

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Scaffold(
      appBar: AppBar(title: Text(t.title, style: const TextStyle(fontSize: 16))),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: kOrange,
            child: const Text('Select Match Position',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            child: Live<List<Entry>>(
              create: () => Repo.entries(t.id),
              builder: (context, entries) {
                final taken = entries.map((e) => e.position).toSet();
                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    childAspectRatio: 1.7,
                  ),
                  itemCount: t.maxSlots,
                  itemBuilder: (_, i) {
                    final n = i + 1;
                    final isTaken = taken.contains(n);
                    final isSel = _sel == n;
                    return InkWell(
                      onTap: isTaken ? null : () => setState(() => _sel = n),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('$n',
                              style: TextStyle(
                                  color: isTaken ? Colors.white30 : kOrange,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(width: 6),
                          Icon(
                            isTaken || isSel
                                ? Icons.check_box
                                : Icons.check_box_outline_blank,
                            color: isTaken
                                ? Colors.white24
                                : isSel
                                    ? kYellow
                                    : Colors.white54,
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: kOrange,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                  onPressed: () {
                    if (_sel == null) {
                      snack(context, 'Pehle ek position select karo');
                      return;
                    }
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                JoiningMatchScreen(t: t, position: _sel!)));
                  },
                  child: const Text('JOIN NOW',
                      style: TextStyle(fontWeight: FontWeight.w900)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// STEP 2: JOINING MATCH (balance + in-game name + confirm)
// ---------------------------------------------------------------------------
class JoiningMatchScreen extends StatelessWidget {
  final Tournament t;
  final int position;
  const JoiningMatchScreen({super.key, required this.t, required this.position});

  Widget _line(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(k, style: const TextStyle(color: Colors.white70)),
            Text(v, style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
      );

  Future<void> _confirm(BuildContext context, UserProfile me) async {
    if (me.balance < t.entryFee) {
      snack(context, 'Your wallet balance is too low');
      return;
    }
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showForm(
      context,
      FormDialog(
        title: 'Join Match',
        confirm: 'JOIN',
        note: 'Free Fire me jo in-game naam hai wahi likho. '
            'Galat naam = NO PRIZE / NO REFUND.'
            '${t.teamType == 'Solo' ? '' : '\nTeam ho to sabke naam comma se likho.'}',
        fields: [FieldSpec('In-game name', initial: me.ffName)],
        onSubmit: (v) async {
          if (v[0].length < 2) throw 'In-game name daalo';
          await Repo.joinTournament(t: t, position: position, ffName: v[0]);
        },
      ),
    );
    if (ok == true) {
      nav.pop(); // joining screen
      nav.pop(); // position screen
      messenger.showSnackBar(const SnackBar(
          content: Text('Join ho gaye! Room ID details page par milegi 🔥'),
          behavior: SnackBarBehavior.floating));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Joining Match')),
      body: MeBuilder(
        builder: (context, me) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: kOrange.withAlpha(110))),
              child: Row(
                children: [
                  const Icon(Icons.account_balance_wallet,
                      size: 64, color: kYellow),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      children: [
                        _line('Your Current Balance', '🪙${me.balance}'),
                        _line('Match Entry Fee Per Person',
                            t.entryFee == 0 ? 'FREE' : '🪙${t.entryFee}'),
                        _line('Total Payable', '🪙${t.entryFee}'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Container(
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                  color: kCard, borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    color: kOrange,
                    child: const Text('Selected Position',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Row(
                          children: [
                            Expanded(child: Text('Team', style: TextStyle(fontWeight: FontWeight.bold))),
                            Expanded(child: Text('Position', style: TextStyle(fontWeight: FontWeight.bold))),
                            Expanded(child: Text('Name', style: TextStyle(fontWeight: FontWeight.bold))),
                          ],
                        ),
                        const Divider(color: Colors.white24),
                        Row(
                          children: [
                            const Expanded(child: Text('Team 1')),
                            Expanded(child: Text('$position')),
                            Expanded(
                                child: Text(me.ffName,
                                    overflow: TextOverflow.ellipsis)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: Colors.red.shade700),
                      onPressed: () => Navigator.pop(context),
                      child: const Text('CANCEL'),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: kOrange),
                      onPressed: () => _confirm(context, me),
                      child: const Text('JOIN'),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 40),
            const Text(
              'Note - Please Enter Your In Game Username/Name.',
              style: TextStyle(color: kOrange, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
