import 'package:flutter/material.dart';
import 'data.dart';

// ---------------------------------------------------------------------------
// THEME
// ---------------------------------------------------------------------------
const kBg = Color(0xFF050505);
const kOrange = Color(0xFFE65100);
const kYellow = Color(0xFFFFC107);
const kCard = Color(0xFF1A1109);
const kDeep = Color(0xFF100B06);
const kGrad = LinearGradient(
  colors: [Color(0xFF3B1500), Color(0xFFB34700), Color(0xFF2A0F00)],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: kBg,
      colorScheme: ColorScheme.fromSeed(
          seedColor: kOrange, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(
        backgroundColor: kBg,
        titleTextStyle: TextStyle(
            color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------
void snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(
    SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

String fmtDate(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year} ${two(h)}:${two(d.minute)} ${d.hour >= 12 ? 'pm' : 'am'}';
}

IconData modeIcon(String m) {
  if (m.contains('NIGHT')) return Icons.nightlight_round;
  if (m.contains('HEADSHOT')) return Icons.gps_fixed;
  if (m == 'FULL MAP') return Icons.map;
  if (m.contains('SKILL')) return Icons.bolt;
  if (m.contains('LOSS')) return Icons.trending_up;
  if (m.contains('4V4') || m.contains('2V2')) return Icons.groups;
  return Icons.person;
}

// ---------------------------------------------------------------------------
// GENERIC WIDGETS
// ---------------------------------------------------------------------------
class Loading extends StatelessWidget {
  const Loading({super.key});

  @override
  Widget build(BuildContext context) =>
      const Center(child: CircularProgressIndicator(color: kYellow));
}

class ErrorBox extends StatelessWidget {
  final Object error;
  const ErrorBox({super.key, required this.error});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(friendlyError(error),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.redAccent)),
        ),
      );
}

/// Stream ko ek baar subscribe karke builder chalata hai (loading/error handle karta hai).
class Live<T> extends StatefulWidget {
  final Stream<T> Function() create;
  final Widget Function(BuildContext, T) builder;
  final Widget? loading;
  const Live(
      {super.key, required this.create, required this.builder, this.loading});

  @override
  State<Live<T>> createState() => _LiveState<T>();
}

class _LiveState<T> extends State<Live<T>> {
  late final Stream<T> _stream = widget.create();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<T>(
      stream: _stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorBox(error: snap.error!);
        if (!snap.hasData) return widget.loading ?? const Loading();
        return widget.builder(context, snap.data as T);
      },
    );
  }
}

/// Logged-in user ka live profile (wallet, level, etc.)
class MeBuilder extends StatelessWidget {
  final Widget Function(BuildContext, UserProfile) builder;
  final Widget? loading;
  const MeBuilder({super.key, required this.builder, this.loading});

  @override
  Widget build(BuildContext context) => Live<UserProfile?>(
        create: () => Repo.userStream(Repo.uid),
        loading: loading,
        builder: (c, me) => builder(c, me!),
      );
}

class Avatar extends StatelessWidget {
  final String url;
  final double radius;
  const Avatar({super.key, required this.url, this.radius = 20});

  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: radius,
        backgroundColor: Colors.white12,
        backgroundImage: url.isNotEmpty ? NetworkImage(url) : null,
        child: url.isEmpty
            ? Icon(Icons.person, color: Colors.white54, size: radius)
            : null,
      );
}

/// Tournament banner: apni image URL ho to wo, warna gradient + mode ka naam.
class ModeBanner extends StatelessWidget {
  final String mode, banner;
  final double height;
  const ModeBanner(
      {super.key, required this.mode, this.banner = '', this.height = 170});

  Widget _art() {
    final idx = kModes.indexOf(mode);
    final label = idx >= 0 ? kModeArt[idx] : mode;
    return Container(
      decoration: const BoxDecoration(gradient: kGrad),
      child: Stack(
        children: [
          Positioned(
            right: -12,
            bottom: -12,
            child: Icon(modeIcon(mode), size: height * 0.9, color: Colors.white12),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('READ RULES BEFORE JOINING',
                    style: TextStyle(
                        color: kYellow,
                        fontWeight: FontWeight.bold,
                        fontSize: 11)),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(label,
                      style: const TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.w900,
                          fontStyle: FontStyle.italic)),
                ),
                const Text('TOURNAMENT',
                    style: TextStyle(
                        fontSize: 22,
                        color: kYellow,
                        fontWeight: FontWeight.w900,
                        fontStyle: FontStyle.italic)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        width: double.infinity,
        child: banner.isEmpty
            ? _art()
            : Image.network(banner,
                fit: BoxFit.cover, errorBuilder: (_, __, ___) => _art()),
      );
}

// ---------------------------------------------------------------------------
// FORM DIALOG (text fields + async submit + error message)
// ---------------------------------------------------------------------------
class FieldSpec {
  final String label, initial;
  final TextInputType type;
  const FieldSpec(this.label,
      {this.type = TextInputType.text, this.initial = ''});
}

class FormDialog extends StatefulWidget {
  final String title, confirm;
  final String? note;
  final List<FieldSpec> fields;
  final Future<void> Function(List<String> values) onSubmit;
  const FormDialog({
    super.key,
    required this.title,
    required this.fields,
    required this.onSubmit,
    this.confirm = 'OK',
    this.note,
  });

  @override
  State<FormDialog> createState() => _FormDialogState();
}

class _FormDialogState extends State<FormDialog> {
  late final List<TextEditingController> _c = widget.fields
      .map((f) => TextEditingController(text: f.initial))
      .toList();
  bool _busy = false;
  String? _err;

  @override
  void dispose() {
    for (final c in _c) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _go() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      await widget.onSubmit(_c.map((c) => c.text.trim()).toList());
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() {
          _err = friendlyError(e);
          _busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: kDeep,
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.note != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(widget.note!,
                    style: const TextStyle(color: Colors.white70)),
              ),
            for (var i = 0; i < widget.fields.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(
                  controller: _c[i],
                  keyboardType: widget.fields[i].type,
                  decoration: InputDecoration(
                    labelText: widget.fields[i].label,
                    border: const OutlineInputBorder(),
                  ),
                ),
              ),
            if (_err != null)
              Text(_err!, style: const TextStyle(color: Colors.redAccent)),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: _busy ? null : () => Navigator.pop(context, false),
            child: const Text('CANCEL')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: kOrange),
          onPressed: _busy ? null : _go,
          child: _busy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : Text(widget.confirm),
        ),
      ],
    );
  }
}

Future<bool?> showForm(BuildContext context, FormDialog dialog) =>
    showDialog<bool>(context: context, builder: (_) => dialog);
