import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'data.dart';
import 'payments.dart';
import 'tournaments.dart';

// ---------------------------------------------------------------------------
// WALLET ACTIONS (Add money / Withdraw) - Profile aur Wallet dono use karte hain
// ---------------------------------------------------------------------------
Future<void> showAddMoney(BuildContext context, UserProfile me) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: kDeep,
    isScrollControlled: true,
    builder: (_) => BuyCoinsSheet(me: me),
  );
}

/// Fixed coin packs. User sirf pack dabata hai -> Razorpay.
class BuyCoinsSheet extends StatefulWidget {
  final UserProfile me;
  const BuyCoinsSheet({super.key, required this.me});

  @override
  State<BuyCoinsSheet> createState() => _BuyCoinsSheetState();
}

class _BuyCoinsSheetState extends State<BuyCoinsSheet> {
  int? _busyCoins;
  String? _err;

  Future<void> _buy(CoinPack p) async {
    setState(() {
      _busyCoins = p.coins;
      _err = null;
    });
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await PaymentService.buyPack(p, email: widget.me.email);
      nav.pop();
      messenger.showSnackBar(SnackBar(
          content: Text('${p.coins} coins wallet me add ho gaye 🎉'),
          behavior: SnackBarBehavior.floating));
    } catch (e) {
      if (mounted) {
        setState(() {
          _busyCoins = null;
          _err = friendlyError(e);
        });
      }
    }
  }

  Widget _tile(CoinPack p) {
    final busy = _busyCoins == p.coins;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: _busyCoins != null ? null : () => _buy(p),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kYellow.withAlpha(120)),
          ),
          child: Row(
            children: [
              Text(p.label,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const Spacer(),
              const Icon(Icons.arrow_forward, color: Colors.white54),
              const Spacer(),
              Text('🪙 ${p.coins} Coins',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800, color: kYellow)),
              if (busy)
                const Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2)),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Add Coins',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text(
                'Fixed packs: pack chuno aur Razorpay se pay karo, coins turant wallet me aa jayenge. '
                'Price me payment gateway charge shamil hai.',
                style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 14),
            Live<List<CoinPack>>(
              create: Repo.packs,
              loading: const SizedBox(height: 120, child: Loading()),
              builder: (context, packs) =>
                  Column(children: [for (final p in packs) _tile(p)]),
            ),
            if (_err != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(_err!, style: const TextStyle(color: Colors.redAccent)),
              ),
          ],
        ),
      ),
    );
  }
}

Future<void> showWithdraw(BuildContext context, UserProfile me) async {
  final ok = await showForm(
    context,
    FormDialog(
      title: 'Withdraw',
      confirm: 'REQUEST',
      note: 'Sirf Winning balance (🪙${me.winning}) nikal sakte ho. '
          'Admin aapki UPI ID / UPI number par paise bhejega (1 coin = ₹1).',
      fields: const [
        FieldSpec('Amount (🪙)', type: TextInputType.number),
        FieldSpec('UPI ID ya UPI number'),
      ],
      onSubmit: (v) async {
        final a = int.tryParse(v[0]) ?? 0;
        final okUpi = RegExp(r'^\d{10}$').hasMatch(v[1]) ||
            RegExp(r'^[\w.\-]{2,}@[\w]{2,}$').hasMatch(v[1]);
        if (!okUpi) throw 'Sahi UPI ID (name@bank) ya 10 digit UPI number daalo';
        final cfg = await Repo.config().first;
        if (a < cfg.minWithdraw) {
          throw 'Minimum withdraw ${cfg.minWithdraw} coins hai';
        }
        await Repo.requestWithdraw(a, v[1], me.ffName);
      },
    ),
  );
  if (ok == true && context.mounted) {
    snack(context, 'Withdraw request bhej di gayi');
  }
}

// ---------------------------------------------------------------------------
// WALLET TAB
// ---------------------------------------------------------------------------
class WalletTab extends StatelessWidget {
  const WalletTab({super.key});

  Widget _row(String label, String value,
      {String? btn, VoidCallback? onTap, bool divider = true}) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(color: Colors.white70)),
                  Text(value,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.bold)),
                ],
              ),
              const Spacer(),
              if (btn != null)
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                      backgroundColor: kYellow, foregroundColor: Colors.black),
                  onPressed: onTap,
                  icon: const Icon(Icons.account_balance_wallet, size: 18),
                  label: Text(btn),
                ),
            ],
          ),
        ),
        if (divider) const Divider(color: Colors.white24, height: 1),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return MeBuilder(
      builder: (context, me) => ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kOrange.withAlpha(110))),
            child: Column(
              children: [
                _row('Total Balance', '🪙${me.balance}',
                    btn: 'History',
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const HistoryScreen()))),
                _row('Deposited', '🪙${me.deposited}',
                    btn: 'Add Coins', onTap: () => showAddMoney(context, me)),
                _row('Winning', '🪙${me.winning}',
                    btn: 'Withdraw', onTap: () => showWithdraw(context, me)),
                _row('Total Winnings', '🪙${me.totalWinnings}', divider: false),
                const SizedBox(height: 12),
                const Text('Only winnings can be withdrawn.',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TransactionsScreen extends StatelessWidget {
  final bool onlyCredits;
  const TransactionsScreen({super.key, this.onlyCredits = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text(onlyCredits ? 'Winnings History' : 'Transactions')),
      body: Live<List<TxnRecord>>(
        create: () => Repo.transactions(Repo.uid),
        builder: (context, all) {
          final list =
              onlyCredits ? all.where((t) => t.isCredit).toList() : all;
          if (list.isEmpty) {
            return const Center(
                child: Text('Abhi kuch nahi hai',
                    style: TextStyle(color: Colors.white60)));
          }
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(color: Colors.white12, height: 1),
            itemBuilder: (_, i) {
              final t = list[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: kCard,
                  child: Icon(
                      t.isCredit ? Icons.arrow_downward : Icons.arrow_upward,
                      color: t.isCredit ? Colors.greenAccent : Colors.redAccent),
                ),
                title: Text(t.note),
                subtitle: Text(fmtDate(t.createdAt),
                    style: const TextStyle(color: Colors.white54)),
                trailing: Text('${t.isCredit ? '+' : '-'}🪙${t.amount}',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: t.isCredit ? Colors.greenAccent : Colors.redAccent)),
              );
            },
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// HISTORY: coins / payments (Razorpay) / withdrawals
// ---------------------------------------------------------------------------
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  Widget _empty() => const Center(
      child: Text('Abhi kuch nahi hai', style: TextStyle(color: Colors.white60)));

  Widget _chip(String label, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
            color: c.withAlpha(40),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: c)),
        child: Text(label,
            style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12)),
      );

  Widget _txns() => Live<List<TxnRecord>>(
        create: () => Repo.transactions(Repo.uid),
        builder: (context, list) {
          if (list.isEmpty) return _empty();
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) =>
                const Divider(color: Colors.white12, height: 1),
            itemBuilder: (_, i) {
              final t = list[i];
              final c = t.isCredit ? Colors.greenAccent : Colors.redAccent;
              return ListTile(
                leading: CircleAvatar(
                    backgroundColor: kCard,
                    child: Icon(
                        t.isCredit ? Icons.arrow_downward : Icons.arrow_upward,
                        color: c)),
                title: Text(t.note),
                subtitle: Text(fmtDate(t.createdAt),
                    style: const TextStyle(color: Colors.white54)),
                trailing: Text('${t.isCredit ? '+' : '-'}🪙${t.amount}',
                    style: TextStyle(fontWeight: FontWeight.bold, color: c)),
              );
            },
          );
        },
      );

  Widget _payments() => Live<List<PaymentRec>>(
        create: () => Repo.myOrders(Repo.uid),
        builder: (context, list) {
          if (list.isEmpty) return _empty();
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) =>
                const Divider(color: Colors.white12, height: 1),
            itemBuilder: (_, i) {
              final p = list[i];
              final paid = p.status == 'paid';
              final failed = p.status == 'failed';
              return ListTile(
                leading: const CircleAvatar(
                    backgroundColor: kCard,
                    child: Icon(Icons.payments, color: kYellow)),
                title: Text('🪙${p.coins} Coins  •  ${p.priceLabel}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${fmtDate(p.createdAt)}\nOrder: ${p.id}',
                    style: const TextStyle(color: Colors.white54, fontSize: 12)),
                isThreeLine: true,
                trailing: paid
                    ? _chip('PAID', Colors.greenAccent)
                    : failed
                        ? _chip('FAILED', Colors.redAccent)
                        : _chip('PENDING', Colors.orange),
              );
            },
          );
        },
      );

  Widget _withdrawals() => Live<List<WithdrawRecord>>(
        create: () => Repo.withdrawals(Repo.uid),
        builder: (context, list) {
          if (list.isEmpty) return _empty();
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) =>
                const Divider(color: Colors.white12, height: 1),
            itemBuilder: (_, i) {
              final w = list[i];
              return ListTile(
                leading: const CircleAvatar(
                    backgroundColor: kCard,
                    child: Icon(Icons.account_balance, color: kYellow)),
                title: Text('🪙${w.amount}  →  ₹${w.amount}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('UPI: ${w.upi}\n${fmtDate(w.createdAt)}',
                    style: const TextStyle(color: Colors.white54, fontSize: 12)),
                isThreeLine: true,
                trailing: w.status == 'paid'
                    ? _chip('PAID', Colors.greenAccent)
                    : w.status == 'rejected'
                        ? _chip('REJECTED', Colors.redAccent)
                        : _chip('PENDING', Colors.orange),
              );
            },
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('History'),
          bottom: const TabBar(
            indicatorColor: kYellow,
            labelColor: kYellow,
            tabs: [
              Tab(text: 'Coins'),
              Tab(text: 'Payments'),
              Tab(text: 'Withdrawals'),
            ],
          ),
        ),
        body: TabBarView(children: [_txns(), _payments(), _withdrawals()]),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// PROFILE TAB (user ke design jaisa)
// ---------------------------------------------------------------------------
class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  BoxDecoration _box() => BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kYellow.withAlpha(90)),
      );

  Widget _stat(IconData icon, Color c, String value, String label) => Expanded(
        child: Column(
          children: [
            Icon(icon, color: c, size: 30),
            const SizedBox(height: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800)),
            ),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      );

  Widget _menu(IconData icon, String title, String sub, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(
            children: [
              CircleAvatar(
                  radius: 24,
                  backgroundColor: kDeep,
                  child: Icon(icon, color: kYellow)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 16)),
                    Text(sub,
                        style: const TextStyle(
                            color: Colors.white60, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white54),
            ],
          ),
        ),
      );

  void _push(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return MeBuilder(
      builder: (context, me) => ListView(
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 16),
        children: [
          // ---- header card ----
          Container(
            padding: const EdgeInsets.all(16),
            decoration: _box(),
            child: Row(
              children: [
                Stack(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: kYellow),
                      child: Avatar(url: me.photoUrl, radius: 42),
                    ),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: GestureDetector(
                        onTap: () => _push(context,
                            const ProfileFormScreen(firstTime: false)),
                        child: const CircleAvatar(
                          radius: 14,
                          backgroundColor: kYellow,
                          child: Icon(Icons.edit, size: 16, color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(me.ffName.toUpperCase(),
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w900)),
                          ),
                          const SizedBox(width: 6),
                          const Icon(Icons.workspace_premium, color: kYellow),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text('UID: ${me.ffUid}',
                              style: const TextStyle(color: kYellow)),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            icon: const Icon(Icons.copy, size: 16),
                            onPressed: () {
                              Clipboard.setData(ClipboardData(text: me.ffUid));
                              snack(context, 'UID copy ho gaya');
                            },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(Icons.public, size: 16, color: Colors.white60),
                          const SizedBox(width: 4),
                          const Text('India'),
                          if (me.city.isNotEmpty) ...[
                            const SizedBox(width: 10),
                            const Icon(Icons.place, size: 16, color: Colors.white60),
                            const SizedBox(width: 2),
                            Flexible(
                                child: Text(me.city,
                                    overflow: TextOverflow.ellipsis)),
                          ],
                        ],
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(20)),
                        child: const Text('Play • Compete • Win 🔥',
                            style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ---- level ----
          Container(
            padding: const EdgeInsets.all(14),
            decoration: _box(),
            child: Row(
              children: [
                const Icon(Icons.shield, color: kYellow, size: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Level ${me.level}',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: me.xpInLevel / 1500,
                          minHeight: 10,
                          color: kYellow,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Text('${me.xpInLevel} / 1500 XP',
                    style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ---- stats ----
          Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
            decoration: _box(),
            child: Row(
              children: [
                _stat(Icons.emoji_events, kYellow, '${me.joinedCount}',
                    'Tournaments\nJoined'),
                _stat(Icons.military_tech, Colors.purpleAccent, '${me.wins}',
                    'Wins'),
                _stat(Icons.sports_martial_arts, Colors.redAccent,
                    '${me.matchesPlayed}', 'Matches\nPlayed'),
                _stat(Icons.savings, kYellow, '🪙${me.totalWinnings}',
                    'Total\nWinnings'),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ---- wallet ----
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF2A1A00), kCard]),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kYellow.withAlpha(150)),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                    radius: 28,
                    backgroundColor: kDeep,
                    child: Icon(Icons.account_balance_wallet,
                        color: kYellow, size: 30)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Wallet Balance'),
                      Text('🪙${me.balance}',
                          style: const TextStyle(
                              fontSize: 26, fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                      backgroundColor: kYellow, foregroundColor: Colors.black),
                  onPressed: () => showAddMoney(context, me),
                  icon: const Icon(Icons.add_circle, size: 18),
                  label: const Text('Add Coins'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ---- menu ----
          _menu(Icons.sports_martial_arts, 'Match History',
              'View your recent matches', () => _push(context, const MyMatchesScreen())),
          _menu(Icons.savings, 'Winnings History',
              'Check your received winnings',
              () => _push(context, const TransactionsScreen(onlyCredits: true))),
          _menu(Icons.emoji_events, 'Joined Tournaments',
              'View all your tournament entries',
              () => _push(context, const MyMatchesScreen())),
          _menu(Icons.person, 'Edit Profile', 'Update your information',
              () => _push(context, const ProfileFormScreen(firstTime: false))),
          _menu(Icons.headset_mic, 'Support', 'Need help? Contact us', () async {
            final cfg = await Repo.config().first;
            if (!context.mounted) return;
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: kDeep,
                title: const Text('Support'),
                content: Text(cfg.supportInfo),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('OK'))
                ],
              ),
            );
          }),
          _menu(Icons.settings, 'Settings', 'App settings & preferences',
              () => _push(context, const SettingsScreen())),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// PROFILE FORM (pehli baar + edit): Free Fire name, UID, city
// ---------------------------------------------------------------------------
class ProfileFormScreen extends StatefulWidget {
  final bool firstTime;
  const ProfileFormScreen({super.key, required this.firstTime});

  @override
  State<ProfileFormScreen> createState() => _ProfileFormScreenState();
}

class _ProfileFormScreenState extends State<ProfileFormScreen> {
  final _form = GlobalKey<FormState>();
  final _ffName = TextEditingController();
  final _ffUid = TextEditingController();
  final _city = TextEditingController();
  bool _busy = false, _filled = false;

  @override
  void dispose() {
    _ffName.dispose();
    _ffUid.dispose();
    _city.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await Repo.saveProfile(
          ffName: _ffName.text.trim(),
          ffUid: _ffUid.text.trim(),
          city: _city.text.trim());
      if (!mounted) return;
      if (!widget.firstTime) {
        snack(context, 'Profile save ho gayi');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  InputDecoration _dec(String l, IconData i) => InputDecoration(
        labelText: l,
        prefixIcon: Icon(i, color: kYellow),
        filled: true,
        fillColor: kDeep,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: !widget.firstTime,
        title: Text(widget.firstTime ? 'Apna Profile Banao' : 'Edit Profile'),
        actions: [
          if (widget.firstTime)
            TextButton(
                onPressed: AuthService.signOut, child: const Text('Logout')),
        ],
      ),
      body: MeBuilder(
        builder: (context, me) {
          if (!_filled) {
            _filled = true;
            _ffName.text = me.ffName;
            _ffUid.text = me.ffUid;
            _city.text = me.city;
          }
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              if (widget.firstTime)
                const Padding(
                  padding: EdgeInsets.only(bottom: 16),
                  child: Text(
                      'Tournament join karne ke liye apna Free Fire naam aur UID daalo. '
                      'Ye sahi hona zaroori hai, warna prize nahi milega.',
                      style: TextStyle(color: Colors.white70)),
                ),
              Form(
                key: _form,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _ffName,
                      decoration: _dec('Free Fire In-game Name', Icons.sports_esports),
                      validator: (v) => (v == null || v.trim().length < 2)
                          ? 'Naam daalo'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _ffUid,
                      keyboardType: TextInputType.number,
                      decoration: _dec('Free Fire UID', Icons.badge),
                      validator: (v) => (v == null ||
                              !RegExp(r'^\d{8,12}$').hasMatch(v.trim()))
                          ? '8 se 12 digit ki UID daalo'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _city,
                      decoration: _dec('City (optional)', Icons.place),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                            backgroundColor: kYellow,
                            foregroundColor: Colors.black),
                        onPressed: _busy ? null : _save,
                        child: _busy
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text('SAVE',
                                style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// SETTINGS
// ---------------------------------------------------------------------------
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: MeBuilder(
        builder: (context, me) => ListView(
          children: [
            ListTile(
              leading: const Icon(Icons.email, color: kYellow),
              title: const Text('Account'),
              subtitle: Text(me.email.isEmpty ? me.name : me.email),
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.redAccent),
              title: const Text('Logout'),
              onTap: () async {
                Navigator.of(context).popUntil((r) => r.isFirst);
                await AuthService.signOut();
              },
            ),
          ],
        ),
      ),
    );
  }
}

