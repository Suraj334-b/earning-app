import 'dart:async';
import 'package:flutter/material.dart';
import 'core.dart';
import 'data.dart';
import 'home.dart';
import 'login.dart';
import 'wallet_profile.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  String? initError;
  try {
    await initBackend(); // PocketBase client + saved login
  } catch (e) {
    initError = e.toString();
  }
  runApp(FFApp(initError: initError));
}

class FFApp extends StatelessWidget {
  final String? initError;
  const FFApp({super.key, this.initError});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Desi Clutcher TM',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: initError != null
          ? Scaffold(
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('App start nahi hui.\n\n$initError',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.redAccent)),
                ),
              ),
            )
          : const SplashGate(),
    );
  }
}

/// 2.5 second splash image, phir login/home decide karta hai.
class SplashGate extends StatefulWidget {
  const SplashGate({super.key});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool _splash = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 2500), () {
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_splash) {
      return Scaffold(
        backgroundColor: kBg,
        body: SizedBox.expand(
          child: Image.asset(
            'assets/splash.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Center(
              child: Text('DESI CLUTCHER TM',
                  style: TextStyle(
                      color: kYellow, fontSize: 32, fontWeight: FontWeight.w900)),
            ),
          ),
        ),
      );
    }
    return const AuthGate();
  }
}

/// Login hai? -> profile complete hai? -> Home
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthUser?>(
      stream: AuthService.authChanges,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Loading());
        }
        final user = snap.data;
        if (user == null) return const LoginScreen();
        return UserGate(key: ValueKey(user.id), user: user);
      },
    );
  }
}

class UserGate extends StatefulWidget {
  final AuthUser user;
  const UserGate({super.key, required this.user});

  @override
  State<UserGate> createState() => _UserGateState();
}

class _UserGateState extends State<UserGate> {
  late final Stream<UserProfile?> _profile = Repo.userStream(widget.user.id);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<UserProfile?>(
      stream: _profile,
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(friendlyError(snap.error!),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.redAccent)),
                    const SizedBox(height: 16),
                    FilledButton(
                        onPressed: AuthService.signOut, child: const Text('Logout')),
                  ],
                ),
              ),
            ),
          );
        }
        final p = snap.data;
        if (p == null) return const Scaffold(body: Loading());
        if (!p.profileDone) return const ProfileFormScreen(firstTime: true);
        return const Shell();
      },
    );
  }
}
